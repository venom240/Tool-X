 _   _      ____  _ __   __
| \ | | ___|  _ \| |\ \ / /_  __
|  \| |/ _ \ |_) | __\ V /\ \/ /
| |\  |  __/  __/| |_ | |  >  <
|_| \_|\___|_|    \__||_| /_/\_\
////////////////////////////////
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

+++++++++++++++
Menu Principal:
+++++++++++++++

1) Realizan todo lo que tiene que ver con su git clone infectado
ya sea introduccion del gmail contraseña y receptor en este.

2) Comprecion y movilizacion de nuestro git clone infectado
para asi mas tarde si lo desean subirlo a github y compartir
el enlace en su grupo que desean atacar.

3) Menu de ayuda

4) Salir

××××××××××××
Advertencia:
××××××××××××

Este repositorio esta echo solo con fines educativos cada quien se hace
responsable de su uso y finalidad.
